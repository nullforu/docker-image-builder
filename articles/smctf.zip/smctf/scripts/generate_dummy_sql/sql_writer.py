from datetime import datetime
from typing import Any, Dict, List, Optional, Tuple


def escape_sql_string(s: str) -> str:
    return s.replace("'", "''")


def write_sql_file(
    output_file: str,
    teams: List[Tuple[str, str]],
    users: List[Tuple[str, str, str, str, str, int]],
    challenges: List[
        Tuple[
            str,
            str,
            str,
            int,
            int,
            str,
            bool,
            str,
            bool,
            int,
            str,
            Optional[str],
            Optional[str],
            Optional[str],
        ]
    ],
    registration_keys: List[Tuple[int, str, int, int, int, int, str]],
    registration_key_uses: List[Tuple[int, int, str, str]],
    submissions: List[Tuple[int, int, str, bool, str, bool]],
    meta: Dict[str, Any],
) -> None:
    with open(output_file, "w", encoding="utf-8") as f:
        f.write("-- smctf Dummy Data\n")
        f.write(f"-- Generated at: {datetime.now().isoformat()}\n")
        f.write(f"-- FLAG_HMAC_SECRET: {meta['flag_hmac_secret']}\n")
        f.write(f"-- BCRYPT_COST: {meta['bcrypt_cost']}\n")
        f.write(f"-- Default password for all users: {meta['default_password']}\n")
        if meta.get("include_admin", True):
            f.write(
                f"-- Admin credentials: {meta['admin_email']} / {meta['admin_password']}\n\n"
            )
        else:
            f.write("-- Admin credentials: bootstrapped (see server config)\n\n")

        f.write("-- App Config\n")
        f.write("INSERT INTO app_config (key, value, updated_at) VALUES ('title', 'Welcome to My CTF!', NOW()), ('description', 'this is a sample CTF description.', NOW());\n\n")

        f.write("-- Clear existing data\n")
        f.write("TRUNCATE TABLE submissions, registration_key_uses, registration_keys, challenges RESTART IDENTITY CASCADE;\n")
        if meta.get("bootstrap_mode", False):
            f.write(
                "-- TRUNCATE TABLE users, teams RESTART IDENTITY CASCADE;\n\n"
            )
        else:
            f.write("TRUNCATE TABLE users, teams RESTART IDENTITY CASCADE;\n\n")

        f.write("-- Insert teams\n")
        for idx, (name, created_at) in enumerate(teams, start=1):
            name_esc = escape_sql_string(name)
            prefix = ""
            if meta.get("bootstrap_mode", False) and idx == 1:
                prefix = "-- "
            f.write(f"{prefix}INSERT INTO teams (name, created_at) VALUES ")
            f.write(f"('{name_esc}', '{created_at}');\n")
        f.write("\n")

        f.write("-- Insert users\n")
        for idx, (email, username, password_hash, role, created_at, team_id) in enumerate(users, start=1):
            email_esc = escape_sql_string(email)
            username_esc = escape_sql_string(username)
            password_hash_esc = escape_sql_string(password_hash)
            role_esc = escape_sql_string(role)

            prefix = ""
            if meta.get("bootstrap_mode", False) and idx == 1:
                prefix = "-- "
            f.write(
                f"{prefix}INSERT INTO users (email, username, password_hash, role, team_id, created_at, updated_at) VALUES "
            )
            f.write(
                f"('{email_esc}', '{username_esc}', '{password_hash_esc}', '{role_esc}', {team_id}, '{created_at}', '{created_at}');\n"
            )

        f.write("\n")

        f.write("-- Insert registration keys\n")
        for (
            key_id,
            code,
            created_by,
            team_id,
            max_uses,
            used_count,
            created_at,
        ) in registration_keys:
            code_esc = escape_sql_string(code)

            f.write(
                "INSERT INTO registration_keys (id, code, created_by, team_id, max_uses, used_count, created_at) VALUES "
            )
            f.write(
                f"({key_id}, '{code_esc}', {created_by}, {team_id}, {max_uses}, {used_count}, '{created_at}');\n"
            )

        f.write("\n")
        f.write("-- Insert registration key uses\n")
        for key_id, used_by, used_by_ip, used_at in registration_key_uses:
            used_by_ip_value = f"'{escape_sql_string(used_by_ip)}'"
            f.write(
                "INSERT INTO registration_key_uses (registration_key_id, used_by, used_by_ip, used_at) VALUES "
            )
            f.write(
                f"({key_id}, {used_by}, {used_by_ip_value}, '{used_at}');\n"
            )

        f.write("\n")

        f.write("-- Insert challenges\n")
        for (
            title,
            description,
            category,
            points,
            minimum_points,
            flag_hash,
            is_active,
            created_at,
            stack_enabled,
            stack_target_port,
            stack_pod_spec,
            file_key,
            file_name,
            file_uploaded_at,
        ) in challenges:
            title_esc = escape_sql_string(title)
            description_esc = escape_sql_string(description)
            category_esc = escape_sql_string(category)
            flag_hash_esc = escape_sql_string(flag_hash)
            stack_pod_spec_esc = escape_sql_string(stack_pod_spec)
            stack_pod_spec_value = "NULL" if stack_pod_spec_esc == "" else f"'{stack_pod_spec_esc}'"
            file_key_value = "NULL"
            file_name_value = "NULL"
            file_uploaded_at_value = "NULL"
            if file_key:
                file_key_value = f"'{escape_sql_string(str(file_key))}'"
            if file_name:
                file_name_value = f"'{escape_sql_string(str(file_name))}'"
            if file_uploaded_at:
                file_uploaded_at_value = f"'{escape_sql_string(str(file_uploaded_at))}'"

            f.write(
                "INSERT INTO challenges (title, description, category, points, minimum_points, flag_hash, is_active, created_at, stack_enabled, stack_target_port, stack_pod_spec, file_key, file_name, file_uploaded_at) VALUES "
            )
            f.write(
                f"('{title_esc}', '{description_esc}', '{category_esc}', {points}, {minimum_points}, '{flag_hash_esc}', {is_active}, '{created_at}', {stack_enabled}, {stack_target_port}, {stack_pod_spec_value}, {file_key_value}, {file_name_value}, {file_uploaded_at_value});\n"
            )

        f.write("\n")

        f.write("-- Insert submissions\n")
        for user_id, challenge_id, provided, correct, submitted_at, is_first_blood in submissions:
            provided_esc = escape_sql_string(provided)

            f.write(
                "INSERT INTO submissions (user_id, challenge_id, provided, correct, is_first_blood, submitted_at) VALUES "
            )
            f.write(
                f"({user_id}, {challenge_id}, '{provided_esc}', {correct}, {is_first_blood}, '{submitted_at}');\n"
            )

        f.write("\n")
        f.write("-- Update sequences\n")
        f.write("SELECT setval('teams_id_seq', (SELECT MAX(id) FROM teams));\n")
        f.write("SELECT setval('users_id_seq', (SELECT MAX(id) FROM users));\n")
        f.write(
            "SELECT setval('challenges_id_seq', (SELECT MAX(id) FROM challenges));\n"
        )
        f.write(
            "SELECT setval('registration_keys_id_seq', (SELECT MAX(id) FROM registration_keys));\n"
        )
        f.write(
            "SELECT setval('registration_key_uses_id_seq', (SELECT MAX(id) FROM registration_key_uses));\n"
        )
        f.write(
            "SELECT setval('submissions_id_seq', (SELECT MAX(id) FROM submissions));\n"
        )
