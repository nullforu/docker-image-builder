---
title: Home
nav_order: 1
---

# SMCTF API Documentation

This document is the official REST API documentation for the SMCTF service.
