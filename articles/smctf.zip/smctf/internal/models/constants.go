package models

const (
	AdminRole   string = "admin"
	UserRole    string = "user"
	BlockedRole string = "blocked"
)
