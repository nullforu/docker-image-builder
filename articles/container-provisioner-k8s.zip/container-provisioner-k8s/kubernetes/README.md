> [!NOTE]
> 
> for development environment only. if you are deploying to production, please refer to [nullforu/smctf-infra](https://github.com/nullforu/smctf-infra)

- [cluster](./cluster) - EKS cluster and KinD cluster(local) configuration files.
- [manifests](./manifests) - Kubernetes manifests for deploying Container Provisioner.
