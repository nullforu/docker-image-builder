kind create cluster --name dev --config=kubernetes/cluster/kind.dev.yaml
kubectl label nodes dev-worker role=stack 
kubectl label nodes dev-worker2 role=stack
kubectl apply -f kubernetes/manifests/namespaces.yaml
kubectl apply -f kubernetes/manifests/qoutas.yaml
kubectl apply -f kubernetes/manifests/networkpolicy.yaml
