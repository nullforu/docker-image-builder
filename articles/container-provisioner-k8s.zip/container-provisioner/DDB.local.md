## DynamoDB 스키마 및 동작 원리 (container-provisioner)

이 문서는 현재 컨테이너 프로비저너가 DynamoDB에 스택 정보를 저장하는 방식과
핵심 동작 흐름을 설명합니다. 모든 내용은 최신 스키마(GSI 기반) 기준입니다.

### 테이블 기본 스키마

- 테이블명: `DDB_STACK_TABLE`
- 파티션 키: `pk` (String)
- 정렬 키: `sk` (String)
- GSI: `gsi1`
  - 파티션 키: `gsi1pk` (String)
  - 정렬 키: `gsi1sk` (String)

### 아이템 타입

#### 1) 스택 메타 아이템 (Stack META)

스택 1개당 1개의 메타 아이템만 저장합니다.

- `pk = STACK#{stack_id}`
- `sk = META`
- `gsi1pk = STACKS`
- `gsi1sk = {created_at}` (RFC3339Nano)
- 주요 속성
  - `stack_id`
  - `namespace`
  - `pod_id`
  - `node_id`
  - `node_public_ip` (선택, 없으면 미존재)
  - `pod_spec`
  - `target_port`
  - `node_port`
  - `service_name`
  - `status`
  - `ttl_expires_at`
  - `created_at`
  - `updated_at`
  - `requested_cpu_milli`
  - `requested_memory_bytes`

#### 2) NodePort 락 아이템 (Port lock)

NodePort 충돌 방지를 위한 락 아이템입니다.

- `pk = PORTS`
- `sk = PORT#{node_port}`
- 주요 속성
  - `port`
  - `stack_id` (예약 중이면 빈 문자열, 할당 후 stack_id)
  - `created_at`
  - `locked_at` (Unix timestamp)

### GSI (전체 스택 목록)

- 목적: 전체 스택 목록 조회 (`GET /stacks`)
- GSI 키
  - `gsi1pk = STACKS`
  - `gsi1sk = created_at`
- 조회 방식
  - `Query` on `gsi1` with `gsi1pk = STACKS`

### 주요 동작 흐름

#### 스택 생성

1) NodePort 예약
   - `PORTS` 아이템 생성 (조건부 Put)
   - 이미 존재하면 `locked_at`이 오래된 경우에만 재회수 시도
2) Kubernetes에 Pod/Service 생성
3) DynamoDB에 스택 메타 저장
   - `STACK#{stack_id}` META 아이템 Put (조건부)
   - `PORTS/PORT#{node_port}` Update (stack_id 할당)

#### 스택 조회

- 단건 조회: `GetItem` (`pk=STACK#{stack_id}, sk=META`)
- 전체 조회: GSI `gsi1` Query (`gsi1pk=STACKS`)

#### 스택 상태 업데이트

- `UpdateItem`로 META 아이템만 갱신
  - `status`, `node_id`, `updated_at`

#### 스택 삭제

1) Kubernetes 리소스 삭제 시도 (Pod/Service)
2) DynamoDB 트랜잭션으로 다음 아이템 제거
   - `STACK#{stack_id}` META 삭제
   - `PORTS/PORT#{node_port}` 삭제

### 설계 의도 및 특이점

- **중복 저장 제거**: 과거 `STACKS` 카탈로그 아이템을 삭제하고 GSI로 대체해 쓰기 비용을 줄였습니다.
- **일관성**: 스택 생성/삭제는 트랜잭션으로 처리하여 NodePort 락 정합성을 보장합니다.
- **스캔 회피**: 전체 스택 조회는 GSI Query로 처리합니다.
- **node_public_ip**는 선택 필드이며, 없으면 아예 속성이 저장되지 않습니다.

### 초기화 (DDB 재생성)

테이블은 아래와 같이 생성해야 합니다.

```bash
aws dynamodb create-table \
  --table-name smctf-stacks \
  --attribute-definitions \
    AttributeName=pk,AttributeType=S \
    AttributeName=sk,AttributeType=S \
    AttributeName=gsi1pk,AttributeType=S \
    AttributeName=gsi1sk,AttributeType=S \
  --key-schema \
    AttributeName=pk,KeyType=HASH \
    AttributeName=sk,KeyType=RANGE \
  --global-secondary-indexes \
    'IndexName=gsi1,KeySchema=[{AttributeName=gsi1pk,KeyType=HASH},{AttributeName=gsi1sk,KeyType=RANGE}],Projection={ProjectionType=ALL}' \
  --billing-mode PAY_PER_REQUEST
```
