## Implementation Status

현재 구현은 실제 AWS DynamoDB + Kubernetes Client(`client-go`) 연동을 포함합니다.

- 실제 연동
  - DynamoDB repository (`DDB_USE_MOCK=false`)
  - Kubernetes client-go (`K8S_USE_MOCK=false`)
- 안정성/원자성
  - NodePort 락과 글로벌 리소스 카운터를 `TransactWriteItems`로 처리
  - `STACK_RESOURCE_RESERVE_RATIO` 경계에서 남은 여유가 정확히 임계치(예: 20%)인 경우도 생성 거부
  - 예약만 되고 고아화된 빈 NodePort 락은 `STACK_PORT_LOCK_TTL` 기준으로 재회수
  - 생성 실패 시 Kubernetes 리소스 및 NodePort 락 정리
- 스케줄러
  - TTL 만료 스택 정리
  - Pod/Service 무결성 점검 (둘 중 하나라도 없으면 DDB 스택 정리)
  - 노드 삭제에 따른 orphan 정리
  - Pod가 `Unschedulable`이거나 `STACK_SCHEDULING_TIMEOUT`을 넘기면 생성 에러 반환

### DynamoDB Table Requirement

- Table Name: `DDB_STACK_TABLE`
- Key schema:
  - Partition key: `pk` (String)
  - Sort key: `sk` (String)

서비스는 다음 아이템 패턴을 사용합니다.

- `pk=STACK#{stack_id}, sk=META`
- `pk=GLOBAL, sk=RESOURCES`
- `pk=PORTS, sk=PORT#{node_port}`
- `gsi1pk=STACKS, gsi1sk={created_at}` (전체 스택 목록용 GSI)

## Terraform IaC

`terraform/` 디렉토리에서 DynamoDB 및 접근 IAM 리소스를 생성합니다.

- 포함: DynamoDB, app DynamoDB IAM Policy, EKS IRSA Role(선택)
- 제외: EKS 클러스터 자체 생성

### Quick start

```bash
cd terraform
cp terraform.tfvars.example terraform.tfvars
terraform init
terraform plan
terraform apply
```

상세는 `terraform/README.md`를 참고하세요.

### Development access model (local admin IAM)

개발/테스트에서는 로컬 AWS 자격증명 프로파일(관리자 IAM)을 사용합니다.

- Terraform: `aws_profile` 사용
- App: `.env`의 `AWS_PROFILE` 사용

예시:

```bash
cd terraform
terraform apply -var="aws_profile=your-admin-profile"
```

앱 `.env`:

- `DDB_USE_MOCK=false`
- `DDB_STACK_TABLE=<terraform output dynamodb_table_name>`
- `AWS_REGION=<terraform region>`
- `AWS_PROFILE=your-admin-profile`

출력값 확인:

```bash
cd terraform
terraform output
```

### Production access model (EKS IRSA)

운영에서는 EKS 내부에서 실행되고 IRSA로 DynamoDB 접근 권한을 받습니다.

- Terraform에서 `create_irsa_role=true`
- 기존 EKS OIDC 정보(`eks_oidc_provider_arn`, `eks_oidc_issuer_url`) 주입
- 생성된 `irsa_role_arn`을 ServiceAccount annotation에 설정
- 앱에서는 `AWS_PROFILE` 비움 (InCluster + IRSA 사용)

ServiceAccount 예시:

```yaml
apiVersion: v1
kind: ServiceAccount
metadata:
  name: container-provisioner
  namespace: smctf
  annotations:
    eks.amazonaws.com/role-arn: arn:aws:iam::986129558966:role/smctf-container-provisioner-irsa
```

## Usage Guide

### 1) Prerequisites

- Go `1.25+`
- Kubernetes cluster access (`kubectl` context or in-cluster config)
- AWS account and DynamoDB table

### 2) Install dependencies

```bash
go mod tidy
```

### 3) Configure environment

```bash
cp .env.example .env
```

필요한 값을 실제 환경에 맞게 수정합니다.

### 4) Run server

```bash
go run ./cmd/server
```

기본 바인드 주소는 `:8081` 입니다.

### 5) Health check

```bash
curl -s http://localhost:8081/healthz
```

## API Quick Examples

### Create stack

```bash
curl -X POST http://localhost:8081/stacks \
  -H "Content-Type: application/json" \
  -d '{
    "target_port": [{"container_port": 5000, "protocol": "TCP"}],
    "pod_spec": "apiVersion: v1\nkind: Pod\nmetadata:\n  name: challenge\nspec:\n  containers:\n    - name: app\n      image: ghcr.io/example/challenge:latest\n      ports:\n        - containerPort: 5000\n          protocol: TCP\n      resources:\n        requests:\n          cpu: \"500m\"\n          memory: \"256Mi\"\n        limits:\n          cpu: \"500m\"\n          memory: \"256Mi\"\n"
  }'
```

### Get stack status

```bash
curl -s http://localhost:8081/stacks/{stack_id}/status
```

### Delete stack

```bash
curl -X DELETE -s http://localhost:8081/stacks/{stack_id}
```

## Runtime Modes

### Production mode (real backends)

- `DDB_USE_MOCK=false`
- `K8S_USE_MOCK=false`

이 모드에서는 실제 DynamoDB 및 Kubernetes API를 사용합니다.

### Local mock mode

- `DDB_USE_MOCK=true`
- `K8S_USE_MOCK=true`

로컬 개발 및 HTTP 동작 확인 용도입니다.

## Kubernetes Client Config Resolution

Kubernetes client 설정은 다음 우선순위로 로드됩니다.

1. `K8S_KUBECONFIG`가 설정되어 있으면 해당 경로(+ `K8S_CONTEXT`)를 사용
2. 없으면 `InClusterConfig` 시도 (프로덕션 권장)
3. 둘 다 실패하면 기본 kubeconfig(`~/.kube/config`) + `K8S_CONTEXT` 시도

즉, 프로덕션에서 클러스터 내부 실행 시에는 `K8S_KUBECONFIG`, `K8S_CONTEXT` 없이도 동작합니다.

## Production Operation Guide

### Required AWS permissions

서비스 실행 주체(IAM Role/User)에 최소 다음 DynamoDB 권한이 필요합니다.

- `dynamodb:GetItem`
- `dynamodb:PutItem`
- `dynamodb:UpdateItem`
- `dynamodb:DeleteItem`
- `dynamodb:Query`
- `dynamodb:TransactWriteItems`

리소스는 `DDB_STACK_TABLE` 단일 테이블로 제한하는 것을 권장합니다.

### Required Kubernetes permissions (RBAC)

서비스 계정에 최소 다음 권한이 필요합니다.

- Namespace: `get`, `create`
- Pods: `get`, `create`, `delete`
- Services: `get`, `create`, `delete`
- Nodes: `get`

### InClusterConfig Production Setup

클러스터 내부에서 실행할 때는 Pod에 마운트되는 ServiceAccount 토큰을 통해 API 인증이 이뤄집니다.

- Deployment의 `serviceAccountName` 지정
- `automountServiceAccountToken: true` 유지
- 필요한 RBAC(ClusterRole/ClusterRoleBinding) 부여

아래는 최소 예시입니다.

```yaml
apiVersion: v1
kind: ServiceAccount
metadata:
  name: container-provisioner
  namespace: smctf
---
apiVersion: rbac.authorization.k8s.io/v1
kind: ClusterRole
metadata:
  name: container-provisioner-role
rules:
  - apiGroups: [""]
    resources: ["namespaces"]
    verbs: ["get", "create"]
  - apiGroups: [""]
    resources: ["pods"]
    verbs: ["get", "create", "delete"]
  - apiGroups: [""]
    resources: ["services"]
    verbs: ["get", "create", "delete"]
  - apiGroups: [""]
    resources: ["nodes"]
    verbs: ["get"]
---
apiVersion: rbac.authorization.k8s.io/v1
kind: ClusterRoleBinding
metadata:
  name: container-provisioner-binding
subjects:
  - kind: ServiceAccount
    name: container-provisioner
    namespace: smctf
roleRef:
  apiGroup: rbac.authorization.k8s.io
  kind: ClusterRole
  name: container-provisioner-role
---
apiVersion: apps/v1
kind: Deployment
metadata:
  name: container-provisioner
  namespace: smctf
spec:
  replicas: 2
  selector:
    matchLabels:
      app: container-provisioner
  template:
    metadata:
      labels:
        app: container-provisioner
    spec:
      serviceAccountName: container-provisioner
      automountServiceAccountToken: true
      containers:
        - name: app
          image: <your-image>:<tag>
          ports:
            - containerPort: 8081
          env:
            - name: APP_ENV
              value: "production"
            - name: HTTP_ADDR
              value: ":8081"
            - name: DDB_USE_MOCK
              value: "false"
            - name: K8S_USE_MOCK
              value: "false"
            - name: AWS_REGION
              value: "us-east-1"
            - name: DDB_STACK_TABLE
              value: "smctf-stacks"
```

운영에서는 `K8S_KUBECONFIG`, `K8S_CONTEXT`를 비워두고 InClusterConfig를 사용하세요.

### Recommended operational checks

- `STACK_SCHEDULER_INTERVAL`이 너무 크지 않은지 확인
- `STACK_SCHEDULING_TIMEOUT`이 실제 클러스터 스케줄링 지연보다 충분히 큰지 확인
- NodePort 범위(`STACK_NODEPORT_MIN/MAX`)가 인프라 정책과 충돌하지 않는지 확인
- `STACK_RESOURCE_RESERVE_RATIO`를 운영 용량 정책에 맞게 설정
- `STACK_PORT_LOCK_TTL`을 장애 복구 시간보다 짧게 설정

### Failure handling behavior

- Pod/Service 생성 실패 시 생성 중 리소스를 정리합니다.
- Pod가 스케줄 불가(`Unschedulable`) 상태이거나 타임아웃이면 생성 요청을 실패 처리합니다.
- 노드가 사라진 스택은 스케줄러와 상태 조회 경로에서 정리됩니다.
- 이미 Pod/Service가 없는 삭제 요청은 idempotent 하게 처리됩니다.

## Testing Guide

### Unit tests

```bash
go test ./...
```

### Focused tests

```bash
go test ./internal/stack -run TestValidator
go test ./internal/http/middleware -run TestRequestLoggerSkipsBodyForGET
```

### End-to-end API script (`test_api.sh`)

모든 엔드포인트를 `localhost:8081` 대상으로 호출하고, `kubectl`로 Pod/Service 생성/삭제까지 함께 검증합니다.

사전 조건:

- 앱 서버가 `localhost:8081`에서 실행 중
- `kubectl` 컨텍스트가 대상 클러스터를 가리킴
- 테스트 namespace(`STACK_NAMESPACE`, 기본 `stacks`) 접근 가능

실행:

```bash
./test_api.sh
```

선택 환경변수:

- `API_BASE` (기본 `http://localhost:8081`)
- `STACK_NAMESPACE` (기본 `stacks`)
- `TARGET_PORTS_JSON` (기본 `[{\"container_port\":5000,\"protocol\":\"TCP\"}]`)
- `KUBECTL_TIMEOUT_SECONDS` (기본 `60`)

### Integration test checklist

- 실제 Kubernetes + DynamoDB에서 `POST /stacks` 성공
- NodePort 중복 생성이 방지되는지 확인
- TTL 만료 후 자동 삭제 확인
- 노드 제거 시 `GET /stacks/{id}/status`에서 not found 확인

## Environment Variables

### App

| Name | Default | Description |
|---|---|---|
| `APP_ENV` | `local` | 실행 환경 식별자 |
| `HTTP_ADDR` | `:8081` | HTTP 리스닝 주소 |
| `SHUTDOWN_TIMEOUT` | `10s` | graceful shutdown timeout |
| `API_KEY_ENABLED` | `true` | API key 인증 사용 여부 |
| `API_KEY` | `` | API key 값 (`API_KEY_ENABLED=true`일 때 필수) |

### Logging

| Name | Default | Description |
|---|---|---|
| `LOG_DIR` | `logs` | 로그 디렉터리 |
| `LOG_FILE_PREFIX` | `app` | 로그 파일 prefix |
| `LOG_MAX_BODY_BYTES` | `1048576` | 요청 body 로그 최대 바이트 |

#### Logging Schema (JSON Schema)
```json
{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "title": "Container Provisioner Log Event",
  "type": "object",
  "additionalProperties": true,
  "required": ["ts", "level", "msg", "app"],
  "properties": {
    "ts": {
      "type": "string",
      "format": "date-time",
      "description": "RFC3339 timestamp with timezone"
    },
    "level": {
      "type": "string",
      "enum": ["debug", "info", "warn", "error"]
    },
    "msg": { "type": "string" },
    "app": {
      "type": "string",
      "description": "service:env (e.g., container-provisioner:production)"
    },
    "legacy": { "type": "boolean" },
    "error": {},
    "stack": { "type": "string" },
    "http": {
      "type": "object",
      "additionalProperties": true,
      "properties": {
        "method": { "type": "string" },
        "path": { "type": "string" },
        "status": { "type": "integer" },
        "latency": { "type": "string", "description": "Go duration string" },
        "ip": { "type": "string" },
        "query": { "type": "string" },
        "user_agent": { "type": "string" },
        "content_type": { "type": "string" },
        "content_length": { "type": "integer" },
        "body": { "type": "string" },
        "error": { "type": "string" }
      }
    }
  }
}
```

### Stack provisioning

| Name | Default | Description |
|---|---|---|
| `STACK_NAMESPACE` | `stacks` | 스택 Pod 생성 네임스페이스 |
| `STACK_TTL` | `2h` | 스택 최대 수명 |
| `STACK_SCHEDULER_INTERVAL` | `10s` | 백그라운드 정리 주기 |
| `STACK_NODEPORT_MIN` | `30000` | NodePort 최소값 |
| `STACK_NODEPORT_MAX` | `32767` | NodePort 최대값 |
| `STACK_NODE_ROLE` | `stack` | 스택이 스케줄될 노드 라벨 값 (`role=<value>`) |
| `STACK_PORT_LOCK_TTL` | `30s` | 비정상 종료 시 빈 포트락 재회수 기준 |
| `STACK_RESOURCE_RESERVE_RATIO` | `0.20` | 최소 여유 자원 비율 |
| `STACK_MAX_CPU` | `2` | 스택당 최대 CPU |
| `STACK_MAX_MEMORY` | `512Mi` | 스택당 최대 메모리 |
| `STACK_REQUIRE_INGRESS_NETWORK_POLICY` | `false` | 스택 네임스페이스에 Ingress NetworkPolicy 필수 여부 |
| `CLUSTER_TOTAL_CPU` | `100` | 클러스터 총 CPU (용량 정책 계산용) |
| `CLUSTER_TOTAL_MEMORY` | `64Gi` | 클러스터 총 메모리 (용량 정책 계산용) |
| `STACK_SCHEDULING_TIMEOUT` | `20s` | Pod 스케줄링 대기 timeout |

### DynamoDB

| Name | Default | Description |
|---|---|---|
| `DDB_USE_MOCK` | `false` | 인메모리 저장소 사용 여부 |
| `DDB_STACK_TABLE` | `smctf-stacks` | DynamoDB 테이블명 |
| `DDB_CONSISTENT_READ` | `true` | strong consistency read 사용 여부 |
| `AWS_REGION` | `us-east-1` | AWS region |
| `AWS_ENDPOINT` | `` | 로컬스택 등 커스텀 endpoint (실AWS 사용 시 비움) |
| `AWS_PROFILE` | `` | 로컬 개발용 AWS shared profile (EKS IRSA 운영에서는 비움) |

### Kubernetes

| Name | Default | Description |
|---|---|---|
| `K8S_USE_MOCK` | `false` | Mock K8s client 사용 여부 |
| `K8S_KUBECONFIG` | `` | 개발/테스트용 kubeconfig 절대 경로 (운영 InClusterConfig에서는 비움) |
| `K8S_CONTEXT` | `` | 개발/테스트용 kube context 이름 (운영 InClusterConfig에서는 비움) |
| `K8S_CLIENT_QPS` | `20` | client-go QPS |
| `K8S_CLIENT_BURST` | `40` | client-go burst |

## DynamoDB Initialization Example

이미 존재하는 테이블이 없다면 아래 형태로 생성할 수 있습니다.

```bash
aws dynamodb create-table \
  --table-name smctf-stacks \
  --attribute-definitions \
    AttributeName=pk,AttributeType=S \
    AttributeName=sk,AttributeType=S \
    AttributeName=gsi1pk,AttributeType=S \
    AttributeName=gsi1sk,AttributeType=S \
  --key-schema \
    AttributeName=pk,KeyType=HASH \
    AttributeName=sk,KeyType=RANGE \
  --global-secondary-indexes \
    'IndexName=gsi1,KeySchema=[{AttributeName=gsi1pk,KeyType=HASH},{AttributeName=gsi1sk,KeyType=RANGE}],Projection={ProjectionType=ALL}' \
  --billing-mode PAY_PER_REQUEST
```

## Troubleshooting

- `cluster saturated`: 클러스터 자원 부족 또는 `STACK_RESOURCE_RESERVE_RATIO` 정책에 의해 거부된 상태입니다.
- `no available nodeport`: NodePort 풀 고갈 상태입니다. 범위를 늘리거나 누수 여부를 확인하세요.
- `stack not found` on status: TTL 만료, 노드 삭제 정리, 혹은 이미 삭제된 스택일 수 있습니다.
- `config error` at startup: `.env`의 타입(정수/duration/bool)과 필수 값 누락을 확인하세요.
