# Dynamic Scoring

A Dynamic Scoring challenge is a challenge whose point value decreases after each solve. By reducing the value of the challenge on each solve, all users who have previously solved the challenge will have lowered scores. Thus an easier and more solved challenge will naturally have a lower point value than a harder and less solved challenge.

The current implementation requires the challenge to keep track of three values:

- Initial - The original point valuation
- Decay - (total teams + total unaffiliated users)
- Minimum - The lowest possible point valuation (stored as `minimum_points`)

The value decay logic is implemented with the following math:

```
value = (((minimum - initial) / (decay ** 2)) * (solve_count ** 2)) + initial
value = math.ceil(value)
```

If the number generated is lower than the minimum, the minimum is chosen instead.

uses a parabolic function instead of a linear, exponential, or logarithmic decay function so that higher valued challenges have a slower drop from their initial value.

To disable dynamic scoring, set `minimum` equal to `initial`.

Scores are not stored. Any API that returns points uses the dynamic formula at request time.

Existing challenges should have `minimum_points` populated; otherwise, scores may drop to 0.

# Value Decay Simulator

```py
#!/bin/python3

## Dynamic Scoring Challenge Decay Simulator

## Edit the following variables to provide your 
## desired dynamic challenge settings

# The starting value for a challenge
initial = 500
# The minimum amount of points a challenge can be
minimum = 100
# How many solves before the challenge reaches its minimum value
decay = 50

import math
solves = 0
value = (((minimum - initial)/(decay**2)) * (solves**2)) + initial
while value > minimum:
  # The value of the challenge after i solves
  value = (((minimum - initial)/(decay**2)) * (solves**2)) + initial
  value = math.ceil(value)
  print(solves, "solves", value, "points")
  solves += 1
```

```py
0 solves 500 points
1 solves 500 points
2 solves 500 points
3 solves 499 points
4 solves 498 points
5 solves 496 points
...
48 solves 132 points
49 solves 116 points
50 solves 100 points
```

예를 들어서 초기 값이 500, 최소 값이 100인 챌린지가 있고
무소속 유저 10명, 팀이 총 20개가 있다고 가정합시다. (decay = 30 = 팀 수 + 무소속 유저 수)
이때 만약 모든 팀과 무소속 유저가 해당 문제를 풀었다면, 그 문제의 점수는 100점이 됩니다.

최종적으로 유저가 초반에 500점 문제를 풀어 최종 500점을 획득했더라도,
30명의 무소속 유저들 + 팀들이 해당 문제를 풀어 최소값인 100점으로 낮아진다면 공식에 따라 해당 유저의 점수도 100점으로 낮아지게 계산됩니다.
